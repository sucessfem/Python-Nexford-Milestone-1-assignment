from datetime import datetime, timedelta

class Product:
    def __init__(self, product_id, product_name, product_description, product_price, product_status='activated'):
        self.product_id = product_id
        self.product_name = product_name
        self.product_description = product_description
        self.product_price = product_price
        self.product_status = product_status
    
    def update(self, new_name=None, new_description=None, new_price=None):
        if new_name:
            self.product_name = new_name
        if new_description:
            self.product_description = new_description
        if new_price:
            self.product_price = new_price

    def susoend(self):
        self.product_status = 'suspended'
        
    def reactivate(self):
        self.product_status = 'activated'
        
    def remove(self):
        self.product_status = 'removed'
    
    def __str__(self):
        return f"Product [Product ID: {self.product_id}, \nProduct Name: {self.product_name}, \nProduct Description: {self.product_description}, \nProduct Price: {self.product_price}, \nProduct Status: {self.product_status}]\n"

class Policyholder:
    def __init__(self, id, name, email_address, status='activated'):
        self.id = id
        self.name = name
        self.email_address = email_address
        self.status = status
        self.products = []

    def add_product(self, product):
        self.products.append(product)
    
    def suspend(self):
        self.status = 'suspended'
    
    def reactivate(self):
        self.status = 'activated'

    def __str__(self):
        products_str = ', '.join([str(product) for product in self.products])
        return f"Policyholder [ID: {self.id}, \nName: {self.name}, \nEmail Address: {self.email_address}, \nStatus: {self.status}, \nProducts: {products_str}]\n"

class Payment:
    def __init__(self, id, policyholder_id, product_id, amount, when_due, date=None):
        self.id = id
        self.policyholder_id = policyholder_id
        self.product_id = product_id
        self.amount = amount
        self.when_due = when_due
        self.date = date
        self.paid = False
    
    def pay(self):
        self.paid = True
    
    def remind(self):
        if not self.paid and datetime.now() > self.when_due:
            print(f"Reminder: Payment of {self.amount} for Policyholder with ID: {self.policyholder_id} is overdue.")
    
    def penalize(self, penalty):
        if not self.paid and datetime.now() > self.when_due:
            self.amount += penalty
            print(f"Penalized. New amount: {self.amount}")
    
    def __str__(self):
        return f"Payment [ID: {self.id}, \nPolicyholder ID: {self.policyholder_id}, \nProduct ID: {self.product_id}, \nAmount: {self.amount}, \nDue Date: {self.when_due}, \nPaid: {self.paid}]\n"

def main():
    # Create products
    product1 = Product(1, "Bank Mortgage", "Insuranve for Mortgage at Bank", 10000.0)
    product2 = Product(2, "Full Health Insurance", "100 percent health insurance coverage", 4700.0)

    # Create policyholders
    policyholders = [
        Policyholder(1, "Olufemi Fadipe", "olufemifadipe@gmail.com"),
        Policyholder(2, "Chioma Vivian", "chiomavivian@gmail.com")
    ]

    # add products to policyholders
    policyholders[0].add_product(product1)
    policyholders[1].add_product(product2)
    policyholders[0].add_product(product2)
    policyholders[1].add_product(product1)

    # Process payments
    when_due = datetime.now() + timedelta(days=30)  # Due date set to 30 days from now
    payments = [
        Payment(id=1, policyholder_id=1, product_id=1, amount=10000.0, when_due=when_due),
        Payment(id=2, policyholder_id=2, product_id=2, amount=4700.0, when_due=when_due)
    ]

    # Process all payments
    for payment in payments:
        payment.pay()

    # Display account details
    for policyholder in policyholders:
        print(policyholder)

    # Display payment details
    for payment in payments:
        print(payment)       
        
if __name__ == '__main__':
    main()
